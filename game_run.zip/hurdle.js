let canvasHurdle = document.getElementById("hurdle");
let ctxHurdle = hurdle.getContext("2d");

canvasHurdle.width = 4000;
canvasHurdle.height = 600;
canvasHurdle.x = 1000;
